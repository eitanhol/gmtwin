/**
 * PLACEHOLDER STOCKFISH.JS
 *
 * This is NOT the real Stockfish.js file!
 *
 * If you're seeing this message in your browser console, it means you need to:
 * 1. Replace this file with the real stockfish.js
 * 2. Make sure stockfish.wasm is in the same directory
 *
 * The real Stockfish.js file can be downloaded from:
 * https://github.com/nmrugg/stockfish.js/releases
 */

// Use localStorage to track if we've shown the alert already
const hasShownPlaceholderAlert = localStorage.getItem("hasShownPlaceholderAlert")

console.error("⚠️ ERROR: You are using the placeholder stockfish.js file!")
console.error(
  "⚠️ Please replace this with the real stockfish.js file and ensure stockfish.wasm is in the same directory.",
)
console.error("⚠️ Download from: https://github.com/nmrugg/stockfish.js/releases")

// Create a fake worker that will show an error message
self.onmessage = (e) => {
  self.postMessage("error: This is a placeholder Stockfish.js file. Please replace with the real file.")
}

// If loaded directly (not as a worker), show an alert only once
if (typeof window !== "undefined" && !hasShownPlaceholderAlert) {
  window.addEventListener("DOMContentLoaded", () => {
    alert(
      "PLACEHOLDER STOCKFISH.JS DETECTED!\n\nYou need to replace this with the real stockfish.js file and ensure stockfish.wasm is in the same directory.\n\nDownload from: https://github.com/nmrugg/stockfish.js/releases",
    )
    localStorage.setItem("hasShownPlaceholderAlert", "true")
  })
}

// Fake Stockfish constructor that will show errors
function Stockfish() {
  return {
    postMessage: function (msg) {
      console.error("⚠️ Placeholder Stockfish.js: Cannot process command:", msg)
      console.error("⚠️ Please replace with the real stockfish.js file")

      // For async operations, return a fake response after a delay
      setTimeout(() => {
        if (this.onmessage) {
          this.onmessage({ data: "error: This is a placeholder Stockfish.js file. Please replace with the real file." })
        }
      }, 500)
    },
    onmessage: null,
    terminate: () => {
      console.log("Terminating placeholder Stockfish instance")
    },
  }
}

// Export the fake Stockfish constructor
if (typeof module !== "undefined" && module.exports) {
  module.exports = Stockfish
} else if (typeof window !== "undefined") {
  window.Stockfish = Stockfish
}
